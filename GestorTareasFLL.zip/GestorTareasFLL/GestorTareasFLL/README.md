# GestorTareasFLL

Aplicacion web de gestion de tareas desarrollada como proyecto final del modulo de programacion web del primer curso de Desarrollo de Aplicaciones Web (DAW).

## Descripcion

GestorTareasFLL permite al usuario crear, visualizar, editar y eliminar tareas de forma sencilla. Cada tarea tiene un titulo, una descripcion, una prioridad, un estado y una fecha limite opcional. Las tareas se guardan automaticamente en el navegador para que no se pierdan al cerrar la pagina.

## Tecnologias utilizadas

- **React 18** - Framework de JavaScript para construir la interfaz
- **Vite** - Herramienta de construccion y servidor de desarrollo
- **CSS puro** - Estilos propios sin ninguna libreria externa
- **localStorage** - Persistencia de datos en el navegador

## Funcionalidades

- Crear tareas nuevas con titulo, descripcion, prioridad, estado y fecha limite
- Editar cualquier tarea existente
- Eliminar tareas con confirmacion previa
- Marcar tareas como completadas (o desmarcarlas)
- Filtrar tareas por estado y por prioridad
- Ordenar tareas por fecha de creacion, fecha limite, prioridad o titulo
- Los datos se guardan automaticamente en el navegador (localStorage)
- Diseno adaptable a movil, tablet y escritorio

## Estructura del proyecto

```
GestorTareasFLL/
  src/
    componentes/
      Encabezado.jsx       # Cabecera de la aplicacion
      FormularioTarea.jsx  # Formulario de crear y editar
      BarraFiltros.jsx     # Controles de filtrado y ordenacion
      ListaTareas.jsx      # Contenedor de la lista
      TarjetaTarea.jsx     # Tarjeta individual de cada tarea
    estilos/
      global.css           # Variables y estilos base
      App.css
      Encabezado.css
      FormularioTarea.css
      BarraFiltros.css
      ListaTareas.css
      TarjetaTarea.css
    App.jsx                # Componente raiz con toda la logica
    main.jsx               # Punto de entrada
  index.html
  package.json
  vite.config.js
```

## Instalacion y puesta en marcha

Necesitas tener instalado **Node.js** (version 16 o superior).

1. Clona o descarga el repositorio.
2. Abre una terminal en la carpeta del proyecto.
3. Instala las dependencias:

```bash
npm install
```

4. Inicia el servidor de desarrollo:

```bash
npm run dev
```

5. Abre el navegador en la direccion que aparece en la terminal (normalmente `http://localhost:5173`).

Para generar la version de produccion:

```bash
npm run build
```

## Autor

Proyecto final de 1.o DAW - GestorTareasFLL
