import TarjetaTarea from './TarjetaTarea.jsx'
import '../estilos/ListaTareas.css'

// Componente contenedor de la lista de tareas
function ListaTareas({ tareas, alEditar, alEliminar, alCompletar }) {

  // Si no hay tareas, mostrar un mensaje
  if (tareas.length === 0) {
    return (
      <div className="lista-vacia">
        <p className="lista-vacia-texto">No hay tareas que mostrar.</p>
        <p className="lista-vacia-subtexto">
          Crea una nueva tarea o cambia los filtros activos.
        </p>
      </div>
    )
  }

  return (
    <div className="lista-tareas">
      {tareas.map((tarea) => (
        <TarjetaTarea
          key={tarea.id}
          tarea={tarea}
          alEditar={alEditar}
          alEliminar={alEliminar}
          alCompletar={alCompletar}
        />
      ))}
    </div>
  )
}

export default ListaTareas
