import { useState, useEffect } from 'react'
import '../estilos/FormularioTarea.css'

// Valores por defecto para una tarea nueva
const valoresIniciales = {
  titulo: '',
  descripcion: '',
  prioridad: 'Media',
  estado: 'Pendiente',
  fechaLimite: '',
}

// Componente de formulario para crear o editar tareas
function FormularioTarea({ tareaEditar, alCrear, alGuardar, alCancelar }) {
  const [campos, setCampos] = useState(valoresIniciales)
  const [errores, setErrores] = useState({})

  // Si estamos editando, rellenar el formulario con los datos de la tarea
  useEffect(() => {
    if (tareaEditar) {
      setCampos({
        titulo: tareaEditar.titulo || '',
        descripcion: tareaEditar.descripcion || '',
        prioridad: tareaEditar.prioridad || 'Media',
        estado: tareaEditar.estado || 'Pendiente',
        fechaLimite: tareaEditar.fechaLimite || '',
      })
    } else {
      setCampos(valoresIniciales)
    }
    setErrores({})
  }, [tareaEditar])

  // Actualizar un campo del formulario
  function manejarCambio(evento) {
    const { name, value } = evento.target
    setCampos((anterior) => ({ ...anterior, [name]: value }))

    // Limpiar el error de ese campo si lo habia
    if (errores[name]) {
      setErrores((anterior) => ({ ...anterior, [name]: '' }))
    }
  }

  // Validar los campos obligatorios
  function validarFormulario() {
    const nuevosErrores = {}

    if (!campos.titulo.trim()) {
      nuevosErrores.titulo = 'El titulo es obligatorio.'
    } else if (campos.titulo.trim().length > 100) {
      nuevosErrores.titulo = 'El titulo no puede tener mas de 100 caracteres.'
    }

    if (campos.descripcion.length > 500) {
      nuevosErrores.descripcion = 'La descripcion no puede tener mas de 500 caracteres.'
    }

    setErrores(nuevosErrores)
    return Object.keys(nuevosErrores).length === 0
  }

  // Manejar el envio del formulario
  function manejarEnvio(evento) {
    evento.preventDefault()

    if (!validarFormulario()) return

    if (tareaEditar) {
      // Modo edicion: guardamos cambios
      alGuardar({ ...tareaEditar, ...campos })
    } else {
      // Modo creacion: creamos nueva tarea
      alCrear(campos)
    }
  }

  const esEdicion = tareaEditar !== null

  return (
    <div className="contenedor-formulario">
      <h2 className="formulario-titulo">
        {esEdicion ? 'Editar Tarea' : 'Nueva Tarea'}
      </h2>

      <form onSubmit={manejarEnvio} className="formulario" noValidate>
        {/* Campo: Titulo */}
        <div className="grupo-campo">
          <label className="etiqueta" htmlFor="titulo">
            Titulo <span className="obligatorio">*</span>
          </label>
          <input
            id="titulo"
            type="text"
            name="titulo"
            value={campos.titulo}
            onChange={manejarCambio}
            placeholder="Escribe el titulo de la tarea"
            maxLength={100}
            className={errores.titulo ? 'campo-error' : ''}
          />
          {errores.titulo && (
            <span className="mensaje-error">{errores.titulo}</span>
          )}
          <span className="contador-caracteres">
            {campos.titulo.length}/100
          </span>
        </div>

        {/* Campo: Descripcion */}
        <div className="grupo-campo">
          <label className="etiqueta" htmlFor="descripcion">
            Descripcion
          </label>
          <textarea
            id="descripcion"
            name="descripcion"
            value={campos.descripcion}
            onChange={manejarCambio}
            placeholder="Descripcion opcional de la tarea"
            rows={3}
            maxLength={500}
            className={errores.descripcion ? 'campo-error' : ''}
          />
          {errores.descripcion && (
            <span className="mensaje-error">{errores.descripcion}</span>
          )}
          <span className="contador-caracteres">
            {campos.descripcion.length}/500
          </span>
        </div>

        {/* Fila con Prioridad y Estado */}
        <div className="fila-campos">
          {/* Campo: Prioridad */}
          <div className="grupo-campo">
            <label className="etiqueta" htmlFor="prioridad">
              Prioridad
            </label>
            <select
              id="prioridad"
              name="prioridad"
              value={campos.prioridad}
              onChange={manejarCambio}
            >
              <option value="Alta">Alta</option>
              <option value="Media">Media</option>
              <option value="Baja">Baja</option>
            </select>
          </div>

          {/* Campo: Estado */}
          <div className="grupo-campo">
            <label className="etiqueta" htmlFor="estado">
              Estado
            </label>
            <select
              id="estado"
              name="estado"
              value={campos.estado}
              onChange={manejarCambio}
            >
              <option value="Pendiente">Pendiente</option>
              <option value="En Progreso">En Progreso</option>
              <option value="Completada">Completada</option>
            </select>
          </div>
        </div>

        {/* Campo: Fecha Limite */}
        <div className="grupo-campo">
          <label className="etiqueta" htmlFor="fechaLimite">
            Fecha Limite
          </label>
          <input
            id="fechaLimite"
            type="date"
            name="fechaLimite"
            value={campos.fechaLimite}
            onChange={manejarCambio}
          />
        </div>

        {/* Botones de accion */}
        <div className="botones-formulario">
          <button type="submit" className="boton-guardar">
            {esEdicion ? 'Guardar Cambios' : 'Crear Tarea'}
          </button>
          <button
            type="button"
            className="boton-cancelar"
            onClick={alCancelar}
          >
            Cancelar
          </button>
        </div>
      </form>
    </div>
  )
}

export default FormularioTarea
