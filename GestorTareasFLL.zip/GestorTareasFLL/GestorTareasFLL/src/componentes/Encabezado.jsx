import '../estilos/Encabezado.css'

// Componente de encabezado de la aplicacion
function Encabezado({ totalTareas }) {
  return (
    <header className="encabezado">
      <div className="encabezado-contenido">
        <h1 className="encabezado-titulo">GestorTareasFLL</h1>
        <span className="encabezado-contador">
          {totalTareas} {totalTareas === 1 ? 'tarea' : 'tareas'} en total
        </span>
      </div>
    </header>
  )
}

export default Encabezado
