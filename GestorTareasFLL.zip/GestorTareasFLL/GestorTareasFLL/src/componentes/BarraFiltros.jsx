import '../estilos/BarraFiltros.css'

// Componente con los controles de filtrado y ordenacion
function BarraFiltros({ filtros, alCambiarFiltros, totalMostradas }) {

  // Actualizar un filtro individual
  function manejarCambio(evento) {
    const { name, value } = evento.target
    alCambiarFiltros((anterior) => ({ ...anterior, [name]: value }))
  }

  // Resetear todos los filtros a sus valores por defecto
  function resetearFiltros() {
    alCambiarFiltros({
      estado: 'todas',
      prioridad: 'todas',
      orden: 'fecha-desc',
    })
  }

  // Comprobar si hay algun filtro activo (para mostrar el boton de resetear)
  const hayFiltrosActivos =
    filtros.estado !== 'todas' ||
    filtros.prioridad !== 'todas' ||
    filtros.orden !== 'fecha-desc'

  return (
    <div className="barra-filtros">
      <div className="filtros-cabecera">
        <span className="filtros-titulo">Filtros y Ordenacion</span>
        <span className="contador-resultado">
          {totalMostradas} {totalMostradas === 1 ? 'tarea encontrada' : 'tareas encontradas'}
        </span>
      </div>

      <div className="filtros-controles">
        {/* Filtro por Estado */}
        <div className="grupo-filtro">
          <label className="etiqueta-filtro" htmlFor="filtro-estado">
            Estado
          </label>
          <select
            id="filtro-estado"
            name="estado"
            value={filtros.estado}
            onChange={manejarCambio}
            className="selector-filtro"
          >
            <option value="todas">Todas</option>
            <option value="Pendiente">Pendientes</option>
            <option value="En Progreso">En Progreso</option>
            <option value="Completada">Completadas</option>
          </select>
        </div>

        {/* Filtro por Prioridad */}
        <div className="grupo-filtro">
          <label className="etiqueta-filtro" htmlFor="filtro-prioridad">
            Prioridad
          </label>
          <select
            id="filtro-prioridad"
            name="prioridad"
            value={filtros.prioridad}
            onChange={manejarCambio}
            className="selector-filtro"
          >
            <option value="todas">Todas</option>
            <option value="Alta">Alta</option>
            <option value="Media">Media</option>
            <option value="Baja">Baja</option>
          </select>
        </div>

        {/* Ordenacion */}
        <div className="grupo-filtro">
          <label className="etiqueta-filtro" htmlFor="filtro-orden">
            Ordenar por
          </label>
          <select
            id="filtro-orden"
            name="orden"
            value={filtros.orden}
            onChange={manejarCambio}
            className="selector-filtro"
          >
            <option value="fecha-desc">Mas recientes primero</option>
            <option value="fecha-asc">Mas antiguas primero</option>
            <option value="fecha-limite">Proximas a vencer</option>
            <option value="prioridad-alta">Prioridad (Alta a Baja)</option>
            <option value="prioridad-baja">Prioridad (Baja a Alta)</option>
            <option value="titulo-az">Titulo (A - Z)</option>
            <option value="titulo-za">Titulo (Z - A)</option>
          </select>
        </div>

        {/* Boton para limpiar filtros */}
        {hayFiltrosActivos && (
          <button className="boton-limpiar" onClick={resetearFiltros}>
            Limpiar filtros
          </button>
        )}
      </div>
    </div>
  )
}

export default BarraFiltros
