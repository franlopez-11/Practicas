import '../estilos/TarjetaTarea.css'

// Devuelve la clase CSS segun la prioridad de la tarea
function obtenerClasePrioridad(prioridad) {
  switch (prioridad) {
    case 'Alta':
      return 'prioridad-alta'
    case 'Media':
      return 'prioridad-media'
    case 'Baja':
      return 'prioridad-baja'
    default:
      return ''
  }
}

// Devuelve la clase CSS segun el estado de la tarea
function obtenerClaseEstado(estado) {
  switch (estado) {
    case 'Pendiente':
      return 'estado-pendiente'
    case 'En Progreso':
      return 'estado-en-progreso'
    case 'Completada':
      return 'estado-completada'
    default:
      return ''
  }
}

// Formatea una fecha ISO a formato legible en espanol
function formatearFecha(fechaISO) {
  if (!fechaISO) return null
  const fecha = new Date(fechaISO + 'T00:00:00')
  return fecha.toLocaleDateString('es-ES', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  })
}

// Componente de tarjeta individual para cada tarea
function TarjetaTarea({ tarea, alEditar, alEliminar, alCompletar }) {
  const estaCompletada = tarea.estado === 'Completada'
  const clasePrioridad = obtenerClasePrioridad(tarea.prioridad)
  const claseEstado = obtenerClaseEstado(tarea.estado)

  // Truncar descripcion a 120 caracteres
  const descripcionTruncada =
    tarea.descripcion && tarea.descripcion.length > 120
      ? tarea.descripcion.substring(0, 120) + '...'
      : tarea.descripcion

  return (
    <div className={`tarjeta-tarea ${estaCompletada ? 'tarjeta-completada' : ''}`}>
      {/* Barra de color lateral segun prioridad */}
      <div className={`barra-prioridad ${clasePrioridad}`}></div>

      <div className="tarjeta-contenido">
        {/* Cabecera de la tarjeta */}
        <div className="tarjeta-cabecera">
          <h3 className={`tarjeta-titulo ${estaCompletada ? 'titulo-tachado' : ''}`}>
            {tarea.titulo}
          </h3>

          <div className="tarjeta-etiquetas">
            {/* Etiqueta de prioridad */}
            <span className={`etiqueta-prioridad ${clasePrioridad}`}>
              {tarea.prioridad}
            </span>

            {/* Etiqueta de estado */}
            <span className={`etiqueta-estado ${claseEstado}`}>
              {tarea.estado}
            </span>
          </div>
        </div>

        {/* Descripcion */}
        {descripcionTruncada && (
          <p className="tarjeta-descripcion">{descripcionTruncada}</p>
        )}

        {/* Pie de la tarjeta: fecha y botones */}
        <div className="tarjeta-pie">
          {/* Fecha limite si existe */}
          {tarea.fechaLimite && (
            <span className="tarjeta-fecha">
              Fecha limite: {formatearFecha(tarea.fechaLimite)}
            </span>
          )}

          {/* Botones de accion */}
          <div className="tarjeta-botones">
            <button
              className="boton-accion boton-completar"
              onClick={() => alCompletar(tarea.id)}
              title={estaCompletada ? 'Marcar como pendiente' : 'Marcar como completada'}
            >
              {estaCompletada ? 'Desmarcar' : 'Completar'}
            </button>

            <button
              className="boton-accion boton-editar"
              onClick={() => alEditar(tarea)}
              title="Editar tarea"
            >
              Editar
            </button>

            <button
              className="boton-accion boton-eliminar"
              onClick={() => alEliminar(tarea.id)}
              title="Eliminar tarea"
            >
              Eliminar
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default TarjetaTarea
