import { useState, useEffect } from 'react'
import Encabezado from './componentes/Encabezado.jsx'
import FormularioTarea from './componentes/FormularioTarea.jsx'
import BarraFiltros from './componentes/BarraFiltros.jsx'
import ListaTareas from './componentes/ListaTareas.jsx'
import './estilos/App.css'

// Clave para guardar en localStorage
const CLAVE_ALMACENAMIENTO = 'gestortareasfll_tareas'

function App() {
  // Estado principal: lista de tareas
  const [tareas, setTareas] = useState([])

  // Estado del formulario: null = cerrado, 'nueva' = crear, objeto = editar
  const [modoFormulario, setModoFormulario] = useState(null)

  // Estado de los filtros activos
  const [filtros, setFiltros] = useState({
    estado: 'todas',
    prioridad: 'todas',
    orden: 'fecha-desc',
  })

  // Mensaje de confirmacion temporal
  const [mensajeConfirmacion, setMensajeConfirmacion] = useState('')

  // Cargar tareas desde localStorage al iniciar la aplicacion
  useEffect(() => {
    const tareasGuardadas = localStorage.getItem(CLAVE_ALMACENAMIENTO)
    if (tareasGuardadas) {
      try {
        const tareasParsed = JSON.parse(tareasGuardadas)
        setTareas(tareasParsed)
      } catch (error) {
        // Si hay un error al leer, empezamos con lista vacia
        setTareas([])
      }
    }
  }, [])

  // Guardar tareas en localStorage cada vez que cambien
  useEffect(() => {
    localStorage.setItem(CLAVE_ALMACENAMIENTO, JSON.stringify(tareas))
  }, [tareas])

  // Mostrar un mensaje de confirmacion durante 3 segundos
  function mostrarMensaje(texto) {
    setMensajeConfirmacion(texto)
    setTimeout(() => {
      setMensajeConfirmacion('')
    }, 3000)
  }

  // Generar un ID unico basado en la fecha actual
  function generarId() {
    return Date.now().toString() + Math.random().toString(36).substring(2, 7)
  }

  // Crear una nueva tarea
  function crearTarea(datosTarea) {
    const nuevaTarea = {
      id: generarId(),
      titulo: datosTarea.titulo,
      descripcion: datosTarea.descripcion,
      prioridad: datosTarea.prioridad,
      estado: datosTarea.estado,
      fechaLimite: datosTarea.fechaLimite,
      fechaCreacion: new Date().toISOString(),
    }
    setTareas((tareasAnteriores) => [nuevaTarea, ...tareasAnteriores])
    setModoFormulario(null)
    mostrarMensaje('Tarea creada correctamente.')
  }

  // Editar una tarea existente
  function guardarEdicion(datosTarea) {
    setTareas((tareasAnteriores) =>
      tareasAnteriores.map((tarea) =>
        tarea.id === datosTarea.id
          ? { ...tarea, ...datosTarea }
          : tarea
      )
    )
    setModoFormulario(null)
    mostrarMensaje('Tarea actualizada correctamente.')
  }

  // Eliminar una tarea con confirmacion
  function eliminarTarea(idTarea) {
    const confirmado = window.confirm('¿Seguro que quieres eliminar esta tarea? Esta accion no se puede deshacer.')
    if (confirmado) {
      setTareas((tareasAnteriores) =>
        tareasAnteriores.filter((tarea) => tarea.id !== idTarea)
      )
      mostrarMensaje('Tarea eliminada.')
    }
  }

  // Marcar una tarea como completada (o volver a pendiente)
  function cambiarEstadoCompletada(idTarea) {
    setTareas((tareasAnteriores) =>
      tareasAnteriores.map((tarea) => {
        if (tarea.id === idTarea) {
          const nuevoEstado = tarea.estado === 'Completada' ? 'Pendiente' : 'Completada'
          return { ...tarea, estado: nuevoEstado }
        }
        return tarea
      })
    )
  }

  // Abrir formulario para editar
  function abrirEdicion(tarea) {
    setModoFormulario(tarea)
  }

  // Cerrar el formulario
  function cerrarFormulario() {
    setModoFormulario(null)
  }

  // Aplicar filtros y ordenacion a la lista de tareas
  function obtenerTareasFiltradas() {
    let resultado = [...tareas]

    // Filtrar por estado
    if (filtros.estado !== 'todas') {
      resultado = resultado.filter((tarea) => tarea.estado === filtros.estado)
    }

    // Filtrar por prioridad
    if (filtros.prioridad !== 'todas') {
      resultado = resultado.filter((tarea) => tarea.prioridad === filtros.prioridad)
    }

    // Ordenar segun criterio seleccionado
    resultado.sort((a, b) => {
      switch (filtros.orden) {
        case 'fecha-desc':
          return new Date(b.fechaCreacion) - new Date(a.fechaCreacion)
        case 'fecha-asc':
          return new Date(a.fechaCreacion) - new Date(b.fechaCreacion)
        case 'fecha-limite':
          if (!a.fechaLimite) return 1
          if (!b.fechaLimite) return -1
          return new Date(a.fechaLimite) - new Date(b.fechaLimite)
        case 'prioridad-alta':
          const ordenPrioridad = { Alta: 0, Media: 1, Baja: 2 }
          return ordenPrioridad[a.prioridad] - ordenPrioridad[b.prioridad]
        case 'prioridad-baja':
          const ordenPrioridadInv = { Alta: 2, Media: 1, Baja: 0 }
          return ordenPrioridadInv[a.prioridad] - ordenPrioridadInv[b.prioridad]
        case 'titulo-az':
          return a.titulo.localeCompare(b.titulo)
        case 'titulo-za':
          return b.titulo.localeCompare(a.titulo)
        default:
          return 0
      }
    })

    return resultado
  }

  const tareasFiltradas = obtenerTareasFiltradas()

  return (
    <div className="contenedor-app">
      <Encabezado totalTareas={tareas.length} />

      <main className="contenido-principal">
        {/* Mensaje de confirmacion */}
        {mensajeConfirmacion && (
          <div className="mensaje-confirmacion">{mensajeConfirmacion}</div>
        )}

        {/* Boton para abrir el formulario de nueva tarea */}
        {modoFormulario === null && (
          <div className="contenedor-boton-nueva">
            <button
              className="boton-nueva-tarea"
              onClick={() => setModoFormulario('nueva')}
            >
              + Nueva Tarea
            </button>
          </div>
        )}

        {/* Formulario de crear o editar */}
        {modoFormulario !== null && (
          <FormularioTarea
            tareaEditar={modoFormulario === 'nueva' ? null : modoFormulario}
            alCrear={crearTarea}
            alGuardar={guardarEdicion}
            alCancelar={cerrarFormulario}
          />
        )}

        {/* Barra de filtros y ordenacion */}
        <BarraFiltros
          filtros={filtros}
          alCambiarFiltros={setFiltros}
          totalMostradas={tareasFiltradas.length}
        />

        {/* Lista de tareas */}
        <ListaTareas
          tareas={tareasFiltradas}
          alEditar={abrirEdicion}
          alEliminar={eliminarTarea}
          alCompletar={cambiarEstadoCompletada}
        />
      </main>
    </div>
  )
}

export default App
